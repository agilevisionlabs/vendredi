// Confirm the buyer's order and keep a running count for this supplier.
function confirmOrder(interchange, api) {
    const count = (api.get("confirmedOrders") || 0) + 1;
    const message = interchange?.messages.find(m => m.segments[0].elements[1][0] === "ORDERS");
    const bgm = message?.segments.find(segment => segment.tag === "BGM");
    const order = bgm?.elements[1]?.[0] || "MANUAL-" + count;
    const reference = order.replace(/[?+':]/g, "?$&");

    api.set("confirmedOrders", count);
    api.log("Accepted purchase order " + order + " for fulfilment.");
    api.send(api.build("ORDRSP:D:96A:UN",
        "BGM+231+OC-" + count + "+29'RFF+ON:" + reference + "'"));
}
