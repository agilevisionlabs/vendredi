// Acknowledge the consignment and reference the original dispatch note.
function receiveDispatch(interchange, api) {
    const count = (api.get("receivedConsignments") || 0) + 1;
    const message = interchange?.messages.find(m => m.segments[0].elements[1][0] === "DESADV");
    const bgm = message?.segments.find(segment => segment.tag === "BGM");
    const dispatch = bgm?.elements[1]?.[0] || "MANUAL-" + count;
    const reference = dispatch.replace(/[?+':]/g, "?$&");

    api.set("receivedConsignments", count);
    api.log("East Dock booked in consignment " + dispatch + ".");
    api.send(api.build("RECADV:D:96A:UN",
        "BGM+352+GR-" + count + "+9'RFF+AAK:" + reference + "'"));
}
